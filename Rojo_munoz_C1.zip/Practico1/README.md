# Practico 1- Grupo 14:
* Joaquin Rojo 202173550-k
* Nicolas Muñoz 202104641-0

# Preguntas a reponder: 

* ¿En qué consistió la actividad?
    La actividad consto de conectarse a un puerto UDP para recibir un texto con multiples conexiones propias a URLs diferentes con protocolos y puertos diferentes que por respuesta dan partes de una impagen que debe ser reconstruida.

* ¿En que tipo de Red estuvo trabajando?
    El tipo de arquitectura de red que se conecto fue una cliente-servidor, donde nostotros como clientes realizamos consultas a diferentes servidores con variados protocolos.
    

* ¿Hubo algún paso de la actividad que se “parecía” a alguno de los protocolos vistos?
    Se podria considerar a una especie de HTTP, aun que no necesaria ya que se usa un socket para crear una conexion con el puerto seleccionado, con de pedirle un retorno un objeto que nosotros, que recibimos para interpretarlo.

    Otro protocolo que podria tener similitud seria el FTP ya que se hace la peticion al servidor y este le devuelve informacion clave para esto que se recibe por el cliente para construir dicho archivo